Alle unserer L�sungen sind in src.
�brigens k�nntest du pr�fen in Aufgabe 9_3.txt ob wir die SQL-Anfrage f�r die Personen, die die Bedingung von youAreFired erf�llen, also die zu entlassen sind, richtig gemacht haben? Danke im Voraus!
